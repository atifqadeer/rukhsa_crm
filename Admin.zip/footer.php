<footer>
    <!-- App js -->
    <script src="dist/assets/js/vendor.min.js"></script>
    <script src="dist/assets/js/app.js"></script>
</footer>
</body>
</html>